-- =====================================================
-- EVIDENCIA DE PRODUCTO
-- GA6-220501096-AA2-EV03
-- Script Base de Datos Proyecto: App Fútbol Sala
-- Modelo Físico - MySQL
-- =====================================================

DROP DATABASE IF EXISTS app_futbol_sala;
CREATE DATABASE app_futbol_sala CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE app_futbol_sala;

-- =============================
-- TABLA: usuarios
-- =============================
CREATE TABLE usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    rol ENUM('Administrador','Jugador','Organizador') DEFAULT 'Jugador',
    fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =============================
-- TABLA: equipos
-- =============================
CREATE TABLE equipos (
    id_equipo INT AUTO_INCREMENT PRIMARY KEY,
    nombre_equipo VARCHAR(50) NOT NULL UNIQUE,
    ciudad VARCHAR(50) NOT NULL,
    fecha_creacion DATE NOT NULL
) ENGINE=InnoDB;

-- =============================
-- TABLA: jugadores
-- =============================
CREATE TABLE jugadores (
    id_jugador INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    posicion ENUM('Portero','Defensa','Ala','Pivot') NOT NULL,
    dorsal INT NOT NULL,
    id_equipo INT,
    CONSTRAINT chk_dorsal CHECK (dorsal > 0),
    CONSTRAINT fk_jugador_equipo
        FOREIGN KEY (id_equipo)
        REFERENCES equipos(id_equipo)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =============================
-- TABLA: torneos
-- =============================
CREATE TABLE torneos (
    id_torneo INT AUTO_INCREMENT PRIMARY KEY,
    nombre_torneo VARCHAR(100) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    CONSTRAINT chk_fechas CHECK (fecha_fin >= fecha_inicio)
) ENGINE=InnoDB;

-- =============================
-- TABLA: partidos
-- =============================
CREATE TABLE partidos (
    id_partido INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATETIME NOT NULL,
    id_equipo_local INT NOT NULL,
    id_equipo_visitante INT NOT NULL,
    goles_local INT DEFAULT 0,
    goles_visitante INT DEFAULT 0,
    id_torneo INT,
    CONSTRAINT fk_partido_local
        FOREIGN KEY (id_equipo_local)
        REFERENCES equipos(id_equipo),
    CONSTRAINT fk_partido_visitante
        FOREIGN KEY (id_equipo_visitante)
        REFERENCES equipos(id_equipo),
    CONSTRAINT fk_partido_torneo
        FOREIGN KEY (id_torneo)
        REFERENCES torneos(id_torneo),
    CONSTRAINT chk_goles_local CHECK (goles_local >= 0),
    CONSTRAINT chk_goles_visitante CHECK (goles_visitante >= 0)
) ENGINE=InnoDB;

-- =============================
-- TABLA: estadisticas
-- =============================
CREATE TABLE estadisticas (
    id_estadistica INT AUTO_INCREMENT PRIMARY KEY,
    id_jugador INT NOT NULL,
    id_partido INT NOT NULL,
    goles INT DEFAULT 0,
    asistencias INT DEFAULT 0,
    tarjetas_amarillas INT DEFAULT 0,
    tarjetas_rojas INT DEFAULT 0,
    CONSTRAINT fk_estadistica_jugador
        FOREIGN KEY (id_jugador)
        REFERENCES jugadores(id_jugador)
        ON DELETE CASCADE,
    CONSTRAINT fk_estadistica_partido
        FOREIGN KEY (id_partido)
        REFERENCES partidos(id_partido)
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- =============================
-- ÍNDICES ADICIONALES
-- =============================
CREATE INDEX idx_jugador_equipo ON jugadores(id_equipo);
CREATE INDEX idx_partido_torneo ON partidos(id_torneo);
CREATE INDEX idx_estadistica_jugador ON estadisticas(id_jugador);

-- =============================
-- DATOS DE PRUEBA (Opcional)
-- =============================
INSERT INTO equipos (nombre_equipo, ciudad, fecha_creacion)
VALUES ('Tigres FS', 'Bogotá', '2024-01-01'),
       ('Leones FS', 'Medellín', '2024-01-10');

INSERT INTO torneos (nombre_torneo, fecha_inicio, fecha_fin)
VALUES ('Liga Nacional Futsal', '2024-02-01', '2024-06-30');

-- =====================================================
-- FIN DEL SCRIPT
-- =====================================================
