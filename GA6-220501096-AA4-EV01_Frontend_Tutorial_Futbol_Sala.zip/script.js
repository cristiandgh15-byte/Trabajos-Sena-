function mostrarMensaje() {
    alert("Consejo: Practica el control del balón todos los días para mejorar tu técnica ⚽");
}
