
let contador = 0;

function sumarEquipo() {
    contador++;
    document.getElementById("contadorEquipos").innerText = 
        "Equipos registrados: " + contador;
}

function toggleModoOscuro() {
    document.body.classList.toggle("dark-mode");
}
